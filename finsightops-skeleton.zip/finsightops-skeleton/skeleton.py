"""
FinSightOps walking skeleton.

The thinnest end-to-end flow:
    document  ->  S3 (proof of storage)  ->  Textract (extract text)
              ->  Balance Sheet agent (gpt-oss on Bedrock)  ->  printed finding

Run:
    python skeleton.py sample_data/sample_balance_sheet.txt      # instant, no Textract
    python skeleton.py path/to/balance_sheet.png                 # real Textract path

Keep it a .txt or an image (.png/.jpg) for now. Multi-page PDF needs the
asynchronous Textract API -- add that later, it is not part of the skeleton.
"""
import os
import sys
import boto3
from dotenv import load_dotenv

load_dotenv()
REGION = os.getenv("AWS_REGION", "us-west-2")
BUCKET = os.getenv("S3_BUCKET")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "openai.gpt-oss-20b-1:0")

s3 = boto3.client("s3", region_name=REGION)
textract = boto3.client("textract", region_name=REGION)
brt = boto3.client("bedrock-runtime", region_name=REGION)

# This is the whole "agent": a system prompt + one model. Everything else is plumbing.
SYSTEM_PROMPT = (
    "You are a balance-sheet review assistant for a finance team. "
    "Given figures extracted from a balance sheet, check whether "
    "Assets = Liabilities + Equity, point out any total that does not foot, "
    "and flag anything that looks misclassified. "
    "Return a short plain-language finding: first line 'STATUS: OK' or "
    "'STATUS: NEEDS REVIEW', then up to three bullet observations. "
    "Do not invent numbers you were not given."
)


def upload_to_s3(path):
    """Optional but proves the storage leg works. Skipped if no bucket set."""
    if not BUCKET or BUCKET.endswith("CHANGEME-dev"):
        print("   (skipping S3 upload -- set S3_BUCKET in .env to enable)")
        return None
    key = f"uploads/{os.path.basename(path)}"
    s3.upload_file(path, BUCKET, key)
    print(f"   uploaded to s3://{BUCKET}/{key}")
    return key


def extract_text(path):
    lower = path.lower()
    if lower.endswith(".txt"):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    if lower.endswith((".png", ".jpg", ".jpeg")):
        with open(path, "rb") as f:
            data = f.read()
        resp = textract.detect_document_text(Document={"Bytes": data})
        return "\n".join(b["Text"] for b in resp["Blocks"] if b["BlockType"] == "LINE")
    raise SystemExit("Use a .txt or an image (.png/.jpg) for the skeleton.")


def analyze(text):
    resp = brt.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=[{"role": "user", "content": [{"text": f"Balance sheet figures:\n\n{text}"}]}],
        inferenceConfig={"maxTokens": 400, "temperature": 0},
    )
    return resp["output"]["message"]["content"][0]["text"].strip()


def main():
    if len(sys.argv) < 2:
        print("Usage: python skeleton.py <path-to-.txt-or-image>")
        sys.exit(1)
    path = sys.argv[1]

    print(f"1) Ingest        {path}")
    upload_to_s3(path)

    print("2) Extract       (Textract / .txt)")
    text = extract_text(path)
    print(f"   {len(text)} characters extracted")

    print(f"3) Analyze       Balance Sheet agent on {MODEL_ID}")
    finding = analyze(text)

    print("\n===================  FINDING  ===================\n")
    print(finding)
    print("\n=================================================")


if __name__ == "__main__":
    main()
