# FinSightOps — Walking Skeleton

The thinnest end-to-end flow, running locally against your AWS account:

    document -> S3 -> Textract -> Balance Sheet agent (gpt-oss on Bedrock) -> finding

Goal of this stage: prove the spine connects to the cloud. No Lambda, no
AgentCore, no UI yet. Total cost to run this is a few cents.

---

## Step 0 — Prerequisites

- Python 3.10+
- AWS CLI v2 installed
- Your AWS account (ready)
- Pick a region with gpt-oss available. `us-west-2` (Oregon) is the safe default;
  keep S3, Textract, and Bedrock all in the same region for the skeleton.

## Step 1 — Get the project and create a virtual environment

    cd finsightops-skeleton
    python -m venv .venv
    source .venv/bin/activate        # Windows: .venv\Scripts\activate
    pip install -r requirements.txt

## Step 2 — Connect your credentials (no hardcoded keys)

Recommended (IAM Identity Center / SSO):

    aws configure sso
    # follow prompts, then:
    aws sts get-caller-identity

Alternative (IAM user access key) if your account isn't on SSO:

    aws configure
    # paste Access Key ID / Secret, set region = us-west-2

Either way the credentials live in your AWS CLI profile, never in code. When you
later move to Lambda / AgentCore you'll use IAM roles and drop keys entirely —
that's what satisfies the "no hardcoded credentials" guardrail.

Minimum IAM permissions for this skeleton (attach to your user/role):

    {
      "Version": "2012-10-17",
      "Statement": [
        { "Effect": "Allow", "Action": "sts:GetCallerIdentity", "Resource": "*" },
        { "Effect": "Allow", "Action": ["bedrock:InvokeModel", "bedrock:Converse"], "Resource": "*" },
        { "Effect": "Allow", "Action": ["textract:DetectDocumentText"], "Resource": "*" },
        { "Effect": "Allow",
          "Action": ["s3:CreateBucket", "s3:PutObject", "s3:GetObject", "s3:ListBucket"],
          "Resource": ["arn:aws:s3:::finsightops-*", "arn:aws:s3:::finsightops-*/*"] }
      ]
    }

## Step 3 — Configure and PROVE the cloud connection

    cp .env.example .env
    # edit .env: set AWS_REGION and (later) S3_BUCKET

    python test_connection.py

Expected output:

    [OK] Connected to AWS account 1234...
    [OK] Bedrock (openai.gpt-oss-20b-1:0) replied: 'connection ok'
    All good. You are connected to the cloud.

If Bedrock errors on model access, gpt-oss is normally auto-enabled — confirm the
model ID and that you're in `us-west-2`. This step is your milestone: **cloud
connected.**

## Step 4 — Create your S3 bucket

Bucket names are globally unique. Use your team name:

    aws s3 mb s3://finsightops-yourteam-dev --region us-west-2

Then set `S3_BUCKET=finsightops-yourteam-dev` in `.env`.

## Step 5 — Run the flow (instant, no document needed)

    python skeleton.py sample_data/sample_balance_sheet.txt

You should see the three stages print, then a FINDING. The sample has a
deliberate error (assets 500,000 vs liabilities + equity 505,000), so a correct
agent returns `STATUS: NEEDS REVIEW` and flags the 5,000 imbalance. If it does,
your reasoning leg works.

## Step 6 — Run the real Textract path

Save a screenshot or photo of a balance sheet as `.png` or `.jpg`, then:

    python skeleton.py path/to/balance_sheet.png

Now all three cloud services are in the loop: S3 (upload), Textract (OCR),
Bedrock (analysis). That's the walking skeleton complete.

---

## Cost note (well inside $200)

- Textract DetectDocumentText: about $1.50 per 1,000 pages.
- gpt-oss-20b on Bedrock: fractions of a cent per run.
- S3: negligible.
Hundreds of dev runs stay in single-digit dollars. Keep the AWS Budgets alarm on.

## Troubleshooting

- `NoCredentialsError` -> run `aws configure sso` (or `aws configure`).
- `AccessDeniedException` -> add the IAM policy above.
- Model/region error -> use `us-west-2` and confirm the model ID in `.env`.
- Textract `UnsupportedDocumentException` -> use a .txt or a .png/.jpg, not a
  multi-page PDF (that needs the async API, added in a later stage).

## What comes next (not now)

1. Clone this agent pattern into the other three specialists.
2. Add a Supervisor that calls the specialists and reconciles.
3. Move the flow into Lambda + Step Functions (human-in-the-loop gate).
4. Wrap it in AgentCore, then the UI.

Keep each addition behind a working skeleton — never break the spine.
