"""
Step 3 — prove you can reach the cloud.
Checks two things:
  1. Your AWS credentials work (STS get-caller-identity).
  2. Bedrock will answer a gpt-oss model call in your region.

Run:  python test_connection.py
"""
import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from dotenv import load_dotenv

load_dotenv()
REGION = os.getenv("AWS_REGION", "us-west-2")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "openai.gpt-oss-20b-1:0")


def check_identity():
    sts = boto3.client("sts", region_name=REGION)
    who = sts.get_caller_identity()
    print(f"[OK] Connected to AWS account {who['Account']}")
    print(f"     Identity: {who['Arn']}")


def check_bedrock():
    brt = boto3.client("bedrock-runtime", region_name=REGION)
    resp = brt.converse(
        modelId=MODEL_ID,
        messages=[{"role": "user", "content": [{"text": "Reply with exactly: connection ok"}]}],
        inferenceConfig={"maxTokens": 20, "temperature": 0},
    )
    text = resp["output"]["message"]["content"][0]["text"].strip()
    print(f"[OK] Bedrock ({MODEL_ID}) replied: {text!r}")


if __name__ == "__main__":
    try:
        check_identity()
        check_bedrock()
        print("\nAll good. You are connected to the cloud.")
    except NoCredentialsError:
        print("[FAIL] No AWS credentials found. Run `aws configure sso` or `aws configure` first.")
    except ClientError as e:
        code = e.response["Error"]["Code"]
        print(f"[FAIL] AWS error: {code} -- {e.response['Error']['Message']}")
        if code in ("AccessDeniedException", "AccessDenied"):
            print("       Check your IAM policy includes bedrock:InvokeModel / bedrock:Converse.")
        if "model" in str(e).lower():
            print(f"       Confirm {MODEL_ID} is available in {REGION} (try us-west-2).")
